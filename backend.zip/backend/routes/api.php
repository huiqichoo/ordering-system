<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\ProductController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\OrderDetailController;
use App\Http\Controllers\Api\RestaurantTableController;

Route::prefix('v1')->group(function () {
    Route::get('/products', [ProductController::class, 'index']);
    Route::get('/products/{id}', [ProductController::class, 'show']);
    Route::post('/createProduct', [ProductController::class, 'store']);
    Route::put('/products/{id}', [ProductController::class, 'update']);

    Route::get('/orders', [OrderController::class, 'index']);
    Route::get('/orders/{id}', [OrderController::class, 'show']);
    Route::post('/createOrder', [OrderController::class, 'store']);

    Route::get('/orderDetails', [OrderDetailController::class, 'index']);
    Route::get('/orderDetails/{id}', [OrderDetailController::class, 'show']);
    Route::post('/createOrderDetails', [OrderDetailController::class, 'store']);

    Route::get('/tables', [RestaurantTableController::class, 'index']);
    Route::get('/tables/{id}', [RestaurantTableController::class, 'show']);
});
