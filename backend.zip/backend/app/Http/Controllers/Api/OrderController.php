<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function index() { return response()->json(Order::orderBy('id','desc')->get(), 200); }

    public function show($id) { return response()->json(Order::findOrFail($id), 200); }

    public function store(Request $request)
    {
        $data = $request->validate([
            'store_id'  => 'required|integer',
            'outlet_id' => 'required|integer',
            'table_id'  => 'required|integer',
            'name'      => 'required|string|max:250',
            'charge_id' => 'nullable|integer',
            'status'    => 'sometimes|integer|in:0,1',
            'created_by'=> 'required|integer',
            'edited_by' => 'nullable|integer',
        ]);
        $data['created_at'] = now();
        $data['last_edited'] = now();

        $row = Order::create($data);
        return response()->json($row, 201);
    }
}
