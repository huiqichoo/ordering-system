<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\RestaurantTable;
use Illuminate\Http\Request;

class RestaurantTableController extends Controller
{
    public function index() { return response()->json(RestaurantTable::all(), 200); }
    public function show($id) { return response()->json(RestaurantTable::findOrFail($id), 200); }
}
