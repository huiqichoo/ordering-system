<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index()
    {
        return response()->json(Product::orderBy('id','desc')->get(), 200);
    }

    public function show($id)
    {
        $product = Product::findOrFail($id);
        return response()->json($product, 200);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'store_id'    => 'required|integer',
            'category_id' => 'required|integer',
            'sku'         => 'required|string|max:50',
            'name'        => 'required|string|max:255',
            'price'       => 'required|numeric',
            'created_by'  => 'required|integer',
        ]);

        $data['created_at'] = now();
        $data['last_edited'] = now();

        $product = Product::create($data);
        return response()->json($product, 201);
    }

    public function update(Request $request, $id)
    {
        $product = Product::findOrFail($id);

        $data = $request->validate([
            'store_id'    => 'sometimes|integer',
            'category_id' => 'sometimes|integer',
            'sku'         => 'sometimes|string|max:50',
            'name'        => 'sometimes|string|max:255',
            'price'       => 'sometimes|numeric',
            'created_by'  => 'sometimes|integer',
        ]);

        $data['last_edited'] = now();

        $product->update($data);
        return response()->json($product, 200);
    }
}
