<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\OrderDetail;
use Illuminate\Http\Request;

class OrderDetailController extends Controller
{
    public function index() { return response()->json(OrderDetail::orderBy('id','desc')->get(), 200); }
    public function show($id) { return response()->json(OrderDetail::findOrFail($id), 200); }

    public function store(Request $request)
    {
        $data = $request->validate([
            'orders_id'   => 'required|integer',
            'category_id' => 'required|integer',
            'product_id'  => 'required|integer',
            'sku'         => 'required|string|max:50',
            'name'        => 'required|string|max:255',
            'qty'         => 'required|numeric',
            'price'       => 'required|numeric',
            'created_by'  => 'required|integer',
        ]);
        $data['created_at'] = now();
        $data['last_edited'] = now();

        $row = OrderDetail::create($data);
        return response()->json($row, 201);
    }
}
