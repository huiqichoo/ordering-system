<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RestaurantTable extends Model
{
    protected $table = 'restaurant_table';
    protected $primaryKey = 'table_id';
    public $timestamps = false;

    protected $fillable = [
        'outlet_id', 'table_number', 'capacity', 'created_at'
    ];
}
