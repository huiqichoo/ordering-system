<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $table = 'products';
    public $timestamps = false;

    protected $fillable = [
        'store_id','category_id','sku','name','price',
        'created_by','last_edited','created_at'
    ];
}
