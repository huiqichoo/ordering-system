<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderDetail extends Model
{
    protected $table = 'order_details';
    public $timestamps = false;

    protected $fillable = [
        'orders_id','category_id','product_id','sku','name',
        'qty','price','created_by','last_edited','created_at'
    ];
}
