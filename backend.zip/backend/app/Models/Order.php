<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $table = 'orders';
    public $timestamps = false;

    protected $fillable = [
        'store_id','outlet_id','table_id','name','charge_id','status',
        'created_by','edited_by','last_edited','created_at'
    ];
}
